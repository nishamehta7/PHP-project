Please use "admin" for the username and "pass" for the password
